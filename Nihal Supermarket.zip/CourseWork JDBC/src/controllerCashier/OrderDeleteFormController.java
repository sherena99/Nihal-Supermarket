package controllerCashier;

import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import model.Customer;
import model.Order;

public class OrderDeleteFormController {
    public AnchorPane orderDeleteFormContext;
    public TextField txtOrderId;
    public TextField txtCustomerId;
    public TextField txtOrderDate;
    public TextField txtOrderTime;
    public TextField txtOrderCost;

    public void searchOrderButtonOnAction(ActionEvent actionEvent) {


    }

    public void deleteButtonOnAction(ActionEvent actionEvent) {
    }
}
