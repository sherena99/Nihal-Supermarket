package controllerManagement;

import model.Item;

import java.sql.SQLException;

public interface ItemDetails {
    public boolean saveItem(Item i) throws SQLException, ClassNotFoundException;
    public boolean updateItem(Item i) throws SQLException, ClassNotFoundException;
    public boolean deleteItem(String itemCode) throws SQLException, ClassNotFoundException;
    public Item getItem(String itemCode) throws SQLException, ClassNotFoundException;
}


