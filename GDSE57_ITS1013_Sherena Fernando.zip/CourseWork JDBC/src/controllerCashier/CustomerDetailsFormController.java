package controllerCashier;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

public class CustomerDetailsFormController {
    public AnchorPane customerDetailsFormContext;
    public AnchorPane loadCustomerDetailsContext;

    public void goBackButtonOnAction(ActionEvent actionEvent) throws IOException {
        URL resource = getClass().getResource("../viewCashier/CashierDashBoardForm.fxml");
        Parent load = FXMLLoader.load(resource);
        Stage window = (Stage) customerDetailsFormContext.getScene().getWindow();
        window.setScene(new Scene(load));
    }

    public void addNewCustomerOnAction(ActionEvent actionEvent) throws IOException {
        URL resource = getClass().getResource("../viewCashier/AddNewCustomerForm.fxml");
        Parent load = FXMLLoader.load(resource);
        loadCustomerDetailsContext.getChildren().clear();
        loadCustomerDetailsContext.getChildren().add(load);
    }

    public void updateCustomerOnAction(ActionEvent actionEvent) throws IOException {
        URL resource = getClass().getResource("../viewCashier/UpdateCustomerForm.fxml");
        Parent load = FXMLLoader.load(resource);
        loadCustomerDetailsContext.getChildren().clear();
        loadCustomerDetailsContext.getChildren().add(load);
    }

    public void removeCustomerOnAction(ActionEvent actionEvent) throws IOException {
        URL resource = getClass().getResource("../viewCashier/DeleteCustomerForm.fxml");
        Parent load = FXMLLoader.load(resource);
        loadCustomerDetailsContext.getChildren().clear();
        loadCustomerDetailsContext.getChildren().add(load);
    }

    public void allCustomerOnAction(ActionEvent actionEvent) {
    }
}
