package controllerCashier;

import model.Customer;
import model.Order;
import model.OrderDetail;

import java.sql.SQLException;

public interface OrderDetails {
    public boolean deleteOrder(Order orderId) throws SQLException, ClassNotFoundException;
    public OrderDetail searchOrder(String orderId) throws SQLException, ClassNotFoundException;
    public boolean updateOrder(OrderDetail o1) throws SQLException, ClassNotFoundException ;
}
