package controllerCashier;

import model.Order;

import java.sql.SQLException;

public interface OrderDetails {
    public boolean deleteOrder(Order orderId) throws SQLException, ClassNotFoundException;
    public boolean searchOrder(String orderId) throws SQLException, ClassNotFoundException;
}
