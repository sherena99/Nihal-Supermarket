package controllerManagement;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

public class ItemDetailsFormController {
    public AnchorPane itemDetailsFormContext;
    public AnchorPane loadItemDetailsContext;

    public void goBackButtonOnAction(ActionEvent actionEvent) throws IOException {
        URL resource = getClass().getResource("../viewManagement/ManagementDashBoardForm.fxml");
        Parent load = FXMLLoader.load(resource);
        Stage window = (Stage) itemDetailsFormContext.getScene().getWindow();
        window.setScene(new Scene(load));
    }

    public void addNewItemOnAction(ActionEvent actionEvent) throws IOException {
        URL resource = getClass().getResource("../viewManagement/RegisterNewItemForm.fxml");
        Parent load = FXMLLoader.load(resource);
        loadItemDetailsContext.getChildren().clear();
        loadItemDetailsContext.getChildren().add(load);
    }

    public void modifyItemOnAction(ActionEvent actionEvent) throws IOException {
        URL resource = getClass().getResource("../viewManagement/ModifyItemDetailsForm.fxml");
        Parent load = FXMLLoader.load(resource);
        loadItemDetailsContext.getChildren().clear();
        loadItemDetailsContext.getChildren().add(load);
    }

    public void removeItemOnAction(ActionEvent actionEvent) throws IOException {
        URL resource = getClass().getResource("../viewManagement/ItemRemoveForm.fxml");
        Parent load = FXMLLoader.load(resource);
        loadItemDetailsContext.getChildren().clear();
        loadItemDetailsContext.getChildren().add(load);
    }
}
